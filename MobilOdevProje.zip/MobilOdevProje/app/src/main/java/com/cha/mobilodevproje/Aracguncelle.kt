package com.cha.mobilodevproje

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.cha.mobilodevproje.databinding.ActivityAracguncelleBinding

class Aracguncelle : AppCompatActivity() {

    private lateinit var binding: ActivityAracguncelleBinding
    private val veriListesi = mutableListOf<String>()
    private lateinit var db: DataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAracguncelleBinding.inflate(layoutInflater)
        setContentView(binding.root)



        db = DataBase(this)

        binding.listView.setOnItemClickListener { _, _, position, _ ->
            val selectedItem = veriListesi[position]


            val alertDialogBuilder = AlertDialog.Builder(this)
            alertDialogBuilder.setTitle("Bilgileri Güncelle")


            val layout = LinearLayout(this)
            layout.orientation = LinearLayout.VERTICAL


            val adSoyadEditText = EditText(this)
            adSoyadEditText.hint = "AdSoyad"
            layout.addView(adSoyadEditText)


            val plakaEditText = EditText(this)
            plakaEditText.hint = "Plaka"
            layout.addView(plakaEditText)


            val markaEditText = EditText(this)
            markaEditText.hint = "Marka"
            layout.addView(markaEditText)

            alertDialogBuilder.setView(layout)

            alertDialogBuilder.setPositiveButton("Tamam") { dialog, which ->

                val adSoyad = adSoyadEditText.text.toString()
                val plaka = plakaEditText.text.toString()
                val marka = markaEditText.text.toString()

                if (adSoyad.isNotEmpty() && plaka.isNotEmpty() && marka.isNotEmpty()) {

                    val eskiBilgiler = selectedItem.split(" - ")
                    val eskiAdSoyad = eskiBilgiler[0]
                    val eskiPlaka = eskiBilgiler[1]
                    val eskiMarka = eskiBilgiler[2]


                    db.veriGuncelle(eskiAdSoyad, eskiPlaka, eskiMarka, adSoyad, plaka, marka)


                    veriListesi[position] = "$adSoyad - $plaka - $marka"
                    val adapter =
                        ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, veriListesi)
                    binding.listView.adapter = adapter

                    Toast.makeText(
                        applicationContext,
                        "Veri Başarıyla Güncellendi",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(applicationContext, "Tüm bilgileri girmelisiniz.", Toast.LENGTH_SHORT).show()
                }
            }

            alertDialogBuilder.setNegativeButton("İptal") { dialog, which ->

                dialog.dismiss()
            }


            alertDialogBuilder.show()
        }

        binding.buttonGoster.setOnClickListener {
            var data = db.verileriOku2()

            veriListesi.clear()
            for (i in 0 until data.size) {
                veriListesi.add("${data[i].adsoyad} - ${data[i].plaka} - ${data[i].marka}")
            }

            val adapter =
                ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, veriListesi)
            binding.listView.adapter = adapter
        }
        val imageButton: ImageButton = findViewById(R.id.imageButton)


        imageButton.setOnClickListener {

            val intent = Intent(this, Baslangic::class.java)


            startActivity(intent)
        }
    }
}



