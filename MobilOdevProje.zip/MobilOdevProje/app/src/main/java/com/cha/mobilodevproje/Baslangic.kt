package com.cha.mobilodevproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Baslangic : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_baslangic)


        val intentaracekle: Button = findViewById(R.id.intentaracekle)
        intentaracekle.setOnClickListener {
            val intent = Intent(this, Aracekle::class.java)
            startActivity(intent)
        }


        val intentaracsil: Button = findViewById(R.id.intentaracsil)
        intentaracsil.setOnClickListener {
            val intent = Intent(this, Aracsil::class.java)
            startActivity(intent)
        }


        val intentaracupdate: Button = findViewById(R.id.intentaracupdate)
        intentaracupdate.setOnClickListener {
            val intent = Intent(this, Aracguncelle::class.java)
            startActivity(intent)
        }

        val İntentgoster: Button = findViewById(R.id.İntentgoster)
        İntentgoster.setOnClickListener {
            val intent = Intent(this, AracGoruntule::class.java)
            startActivity(intent)
        }

    }
}