package com.cha.mobilodevproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast

class AracGoruntule : AppCompatActivity() {

    private lateinit var plakaEditText: EditText
    private lateinit var gosterButton: Button
    private lateinit var adSoyadTextView: TextView
    private lateinit var plakaTextView: TextView
    private lateinit var markaTextView: TextView

    val imageButtonana: ImageButton = findViewById(R.id.imageButtonana)

    private lateinit var db: DataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_arac_goruntule)


        plakaEditText = findViewById(R.id.gosterseneplaka)
        gosterButton = findViewById(R.id.butongostersene)
        adSoyadTextView = findViewById(R.id.textView23)
        plakaTextView = findViewById(R.id.textView22)
        markaTextView = findViewById(R.id.textView24)
        db = DataBase(this)



        gosterButton.setOnClickListener {
            val plaka = plakaEditText.text.toString()

            if (plaka.isNotEmpty()) {
                val arac = db.verileriOku(plaka)

                if (arac != null) {

                    adSoyadTextView.text = "Ad Soyad: ${arac.adsoyad}"
                    plakaTextView.text = "Plaka: ${arac.plaka}"
                    markaTextView.text = "Marka: ${arac.marka}"
                } else {
                    Toast.makeText(this, "Araç bulunamadı.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Plaka alanı boş bırakılamaz.", Toast.LENGTH_SHORT).show()
            }


        }
        imageButtonana.setOnClickListener {

            val intent = Intent(this, Baslangic::class.java)


            startActivity(intent)
        }


    }
}




