package com.cha.mobilodevproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Girisyap : AppCompatActivity() {

    private lateinit var giriskulad: EditText
    private lateinit var girissifre: EditText
    private lateinit var girisyapbtn: Button
    private lateinit var kayitolbtn: Button

    private lateinit var db: DataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_girisyap)

        giriskulad = findViewById(R.id.giriskulad)
        girissifre = findViewById(R.id.girissif)
        girisyapbtn = findViewById(R.id.girisyapbtn)
        kayitolbtn = findViewById(R.id.kayitolbtn)
        db = DataBase(this)


        girisyapbtn.setOnClickListener {
            val kullaniciAdi = giriskulad.text.toString()
            val sifre = girissifre.text.toString()

            if (kullaniciAdi.isNotEmpty() && sifre.isNotEmpty()) {

                val girisBasarili = db.kullaniciGiris(kullaniciAdi, sifre)

                if (girisBasarili) {

                    Toast.makeText(this, "Giriş Başarılı", Toast.LENGTH_LONG).show()
                    val intent = Intent(this, Baslangic::class.java)
                    startActivity(intent)
                }
                else {
                    Toast.makeText(this, "Giriş Başarısız Bilgileri Kontrol Ediniz", Toast.LENGTH_LONG).show()
                }
            }
                else {
                   Toast.makeText(this, "Kullanıcı adı veya şifre alanları boş bırakılamaz.", Toast.LENGTH_LONG).show()


            }
        }
        kayitolbtn.setOnClickListener {

            val intent = Intent(this, Kayitol::class.java)
            startActivity(intent)


        }



    }
}
