package com.cha.mobilodevproje

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.cha.mobilodevproje.databinding.ActivityAracekleBinding

class Aracekle : AppCompatActivity() {
    lateinit var binding: ActivityAracekleBinding
    lateinit var db: DataBase
    lateinit var listView: ListView

    private val veriListesi = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAracekleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val context = this
        db = DataBase(context)




        listView = findViewById(R.id.listView)

        val geridonButton: Button = findViewById(R.id.geridon)
        geridonButton.setOnClickListener {
            val intent = Intent(this, Baslangic::class.java)
            startActivity(intent)
        }


        binding.buttonKaydet.setOnClickListener {
            val adSoyad = binding.editTextAdSoyad.text.toString()
            val plaka = binding.editTextPlaka.text.toString()
            val marka = binding.editTextMarka.text.toString()

            if (adSoyad.isNotEmpty() && plaka.isNotEmpty() && marka.isNotEmpty()) {
                val yeniKopru = Kopru(adSoyad, plaka, marka)

                if (db.veriEklemeKontrol(plaka)) {
                    db.verileriEkle(yeniKopru)

                    veriListesi.add("$adSoyad - $plaka - $marka")

                    val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, veriListesi)
                    listView.adapter = adapter

                    Toast.makeText(applicationContext, "Veri Başarıyla Eklendi", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, Aracguncelle::class.java)
                    startActivity(intent)
                    }
                else {
                    Toast.makeText(applicationContext, "Bu plakaya sahip araç zaten var!", Toast.LENGTH_LONG).show()
                }
                }
                else {
                    Toast.makeText(applicationContext, "Boş bırakılamaz!", Toast.LENGTH_LONG).show()

                }


            }


        val imageButton3: ImageButton = findViewById(R.id.imageButton3)
        imageButton3.setOnClickListener {
            val intent = Intent(this, Baslangic::class.java)
            startActivity(intent)
        }

        }

    }

