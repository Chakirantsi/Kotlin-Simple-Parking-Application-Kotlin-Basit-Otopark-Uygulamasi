package com.cha.mobilodevproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import com.cha.mobilodevproje.databinding.ActivityKayitolBinding

class Kayitol : AppCompatActivity() {
    private lateinit var binding: ActivityKayitolBinding

    private lateinit var db: DataBase
    private lateinit var kayitolbtns: Button
    private lateinit var kayitolad: EditText
    private lateinit var kayitolsif: EditText
    private lateinit var kayitolsifteyit: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityKayitolBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = DataBase(this)

        kayitolbtns = findViewById(R.id.kayitolbtns)
        kayitolad = findViewById(R.id.kayitolad)
        kayitolsif = findViewById(R.id.kayitolsif)
        kayitolsifteyit=findViewById(R.id.kayitolsifteyit)
        kayitolbtns.setOnClickListener {

            val kullaniciadi = kayitolad.text.toString()
            val sifre = kayitolsif.text.toString()
            val sifreTeyit = kayitolsifteyit.text.toString()

            if (kullaniciadi.isNotEmpty() && sifre.isNotEmpty() && sifreTeyit.isNotEmpty()) {
                if (sifre == sifreTeyit) {
                    val yeniKullanici = Kopru.Kullanici(kullaniciAdi = kullaniciadi, sifre = sifre)
                    db.kullaniciKayit(yeniKullanici)
                    finish()

                    val intent = Intent(this, Girisyap::class.java)
                    startActivity(intent)

                } else {
                    Toast.makeText(this, "Şifreler uyuşmuyor, lütfen tekrar deneyin.", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Kullanıcı adı ve şifre alanları boş bırakılamaz.", Toast.LENGTH_LONG).show()
            }
        }

        val imageButtonana1: ImageButton = findViewById(R.id.imageButtonana1)
        imageButtonana1.setOnClickListener {
            val intent = Intent(this, Girisyap::class.java)
            startActivity(intent)
        }


    }
    }