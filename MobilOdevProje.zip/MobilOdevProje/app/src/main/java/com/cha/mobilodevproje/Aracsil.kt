package com.cha.mobilodevproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.cha.mobilodevproje.databinding.ActivityAracekleBinding
import com.cha.mobilodevproje.databinding.ActivityAracsilBinding
import android.widget.ImageButton

class Aracsil : AppCompatActivity() {
    lateinit var binding: ActivityAracsilBinding
    lateinit var db: DataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAracsilBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val context = this
        db = DataBase(context)

        val imageButton2: ImageButton = findViewById(R.id.imageButton2)





        binding.buttonSil.setOnClickListener {
            val girilenPlaka = binding.aracsiltext.text.toString().trim()

            if (girilenPlaka.isNotEmpty()) {
                val arac = db.verileriOku(girilenPlaka)

                if (arac != null) {
                    db.verileriSil(arac.id)
                    Toast.makeText(
                        applicationContext,
                        "Girilen plaka başarıyla silindi.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        applicationContext,
                        "Girilen plaka bulunamadı.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(
                    applicationContext,
                    "Lütfen bir plaka girin.",
                    Toast.LENGTH_SHORT
                ).show()


            }
        }
        imageButton2.setOnClickListener { val intent = Intent(this, Baslangic::class.java)


            startActivity(intent)
        }

    }
}

