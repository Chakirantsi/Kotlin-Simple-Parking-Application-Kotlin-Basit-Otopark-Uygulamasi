package com.cha.mobilodevproje

class Kopru {

    var id: Int = 0
    var adsoyad: String = ""
    var plaka: String = ""
    var marka: String = ""


    constructor(adsoyad: String, plaka: String, marka: String) {
        this.adsoyad = adsoyad
        this.plaka = plaka
        this.marka = marka

    }

    constructor() {

    }
    class Kullanici {

        var id: Int = 0
        var kullaniciAdi: String = ""
        var sifre: String = ""

        constructor(kullaniciAdi: String, sifre: String) {
            this.kullaniciAdi = kullaniciAdi
            this.sifre = sifre
        }

        constructor() {

        }
    }
}

