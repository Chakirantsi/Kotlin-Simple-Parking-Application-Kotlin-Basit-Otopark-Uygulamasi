package com.cha.mobilodevproje

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast


//araclar
val db_name = "Otopark"
val tablo_adi = "Arabalar"
val column_id = "id"
val column_name = "adsoyad"
val column_lplate ="plaka"
val column_brand = "marka"
//kullanıcılar
val kullanici_tablo_adi = "Kullanicilar"
val kullanici_column_id = "id"
val kullanici_column_kullanici_adi = "kullanici_adi"
val kullanici_column_sifre = "sifre"


class DataBase(var context: Context) : SQLiteOpenHelper(context, db_name, null, 1) {


    override fun onCreate(db: SQLiteDatabase?) {
        val createTableKullanici = "CREATE TABLE $kullanici_tablo_adi ( " +
                "$kullanici_column_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$kullanici_column_kullanici_adi VARCHAR(150) UNIQUE, " +
                "$kullanici_column_sifre VARCHAR(150) " +
                ");"
        db?.execSQL(createTableKullanici)


        val createTableArabalar = "CREATE TABLE $tablo_adi ( " +
                "$column_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$column_name VARCHAR(150), " +
                "$column_lplate VARCHAR(150), " +
                "$column_brand VARCHAR(150) " +
                ");"
        db?.execSQL(createTableArabalar)
    }


    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

        db?.execSQL("DROP TABLE IF EXISTS $kullanici_tablo_adi")
        db?.execSQL("DROP TABLE IF EXISTS $tablo_adi")

        onCreate(db)
    }


// KUL DATABASE
    fun kullaniciKayit(kullanici: Kopru.Kullanici) {
        val database = this.writableDatabase
        val cv = ContentValues()
        cv.put(kullanici_column_kullanici_adi, kullanici.kullaniciAdi)
        cv.put(kullanici_column_sifre, kullanici.sifre)

        val result = database.insert(kullanici_tablo_adi, null, cv)

        if (result == -1L) {
            Toast.makeText(context, "Kullanıcı Kaydı Başarısız!", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "Kullanıcı Başarıyla Kaydedildi", Toast.LENGTH_LONG).show()
        }

        database.close()
    }


    fun kullaniciGiris(kullaniciAdi: String, sifre: String): Boolean {
        val database = this.readableDatabase
        val sorgu = "SELECT * FROM $kullanici_tablo_adi WHERE $kullanici_column_kullanici_adi = ? AND $kullanici_column_sifre = ?"
        val args = arrayOf(kullaniciAdi, sifre)
        val cursor = database.rawQuery(sorgu, args)

        val girisBasarili = cursor.count > 0

        cursor.close()
        database.close()

        return girisBasarili
    }


    //ARABA DATABASE

    fun verileriEkle(kopru: Kopru) {
        if (kopru.plaka.isNotEmpty() && veriEklemeKontrol(kopru.plaka)) {
            val database = this.writableDatabase
            val cv = ContentValues()
            cv.put(column_name, kopru.adsoyad)
            cv.put(column_lplate, kopru.plaka)
            cv.put(column_brand, kopru.marka)

            val result = database.insert(tablo_adi, null, cv)

            if (result == -1L) {
                Toast.makeText(context, "Veri Eklenemedi!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Veri Başarıyla Eklendi", Toast.LENGTH_LONG).show()
            }

            database.close()
        } else {
            Toast.makeText(context, "Bu plakaya sahip araç zaten var!", Toast.LENGTH_LONG).show()
        }

    }


    fun veriEklemeKontrol(plaka: String): Boolean {
        val database = this.readableDatabase
        val sorgu = "SELECT * FROM $tablo_adi WHERE $column_lplate = ?"
        val args = arrayOf(plaka)
        val cursor = database.rawQuery(sorgu, args)

        val ekleme = cursor.count == 0

        cursor.close()
        database.close()

        return ekleme
    }

    @SuppressLint("Range")
    fun verileriOku(plaka: String): Kopru? {
        val db = this.readableDatabase
        val sorgu = "SELECT * FROM $tablo_adi WHERE $column_lplate = ?"
        val args = arrayOf(plaka)
        val cursor = db.rawQuery(sorgu, args)

        val arac: Kopru? = if (cursor.moveToFirst()) {
            val kopru = Kopru()
            kopru.id = cursor.getInt(cursor.getColumnIndex(column_id))
            kopru.adsoyad = cursor.getString(cursor.getColumnIndex(column_name))
            kopru.plaka = cursor.getString(cursor.getColumnIndex(column_lplate))
            kopru.marka = cursor.getString(cursor.getColumnIndex(column_brand))
            cursor.close()
            kopru
        } else {
            null
        }

        db.close()
        return arac
    }

    @SuppressLint("Range")
    fun verileriOku2(): MutableList<Kopru> {
        var liste: MutableList<Kopru> = ArrayList()
        val db = this.readableDatabase
        var sorgu = "Select * From " + tablo_adi
        var sonuc = db.rawQuery(sorgu, null)

        if (sonuc.moveToFirst()) {
            do {
                var kopru = Kopru()
                kopru.id = sonuc.getString(sonuc.getColumnIndex(column_id)).toInt()
                kopru.adsoyad = sonuc.getString(sonuc.getColumnIndex(column_name))
                kopru.plaka = sonuc.getString(sonuc.getColumnIndex(column_lplate))
                kopru.marka = sonuc.getString(sonuc.getColumnIndex(column_brand))
                liste.add(kopru)
            } while (sonuc.moveToNext())
        }

        sonuc.close()
        db.close()
        return liste

    }


    fun verileriSil(id: Int) {
        val db = this.writableDatabase
        val whereClause = "$column_id = ?"
        val whereArgs = arrayOf(id.toString())

        val result = db.delete(tablo_adi, whereClause, whereArgs)

        if (result == 0) {
            Toast.makeText(context, "Veri Silme Başarısız", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "Veri Başarıyla Silindi", Toast.LENGTH_LONG).show()
        }

        db.close()
    }


    fun veriGuncelle(
        eskiAdSoyad: String,
        eskiPlaka: String,
        eskiMarka: String,
        yeniAdSoyad: String,
        yeniPlaka: String,
        yeniMarka: String
    ) {
        val db = this.writableDatabase
        val values = ContentValues()

        values.put(column_name, yeniAdSoyad)
        values.put(column_lplate, yeniPlaka)
        values.put(column_brand, yeniMarka)


        db.update(
            tablo_adi,
            values,
            "$column_name = ? AND $column_lplate = ? AND $column_brand = ?",
            arrayOf(eskiAdSoyad, eskiPlaka, eskiMarka)
        )

        db.close()

    }


}



